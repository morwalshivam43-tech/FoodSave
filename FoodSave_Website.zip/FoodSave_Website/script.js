const STORAGE_KEY = "foodsave_demo_v1";
const HISTORY_KEY = "foodsave_history_v1";

const partners = [
  { id:"p1", name:"Green Bowl Kitchen", type:"Restaurant", area:"Shahapur Market", emoji:"🥗", color:"#e7f5e8", description:"Fresh vegetarian meals made daily with seasonal ingredients." },
  { id:"p2", name:"Campus Corner Canteen", type:"College canteen", area:"College Main Block", emoji:"🏫", color:"#fff0d9", description:"A busy campus canteen sharing extra lunch and snack portions." },
  { id:"p3", name:"Daily Crust Bakery", type:"Bakery", area:"Station Road", emoji:"🥐", color:"#fff0e4", description:"Freshly baked bread, buns and pastries available near closing." },
  { id:"p4", name:"Spice Route Eatery", type:"Restaurant", area:"Highway Junction", emoji:"🍛", color:"#fce8df", description:"Comforting Indian meals prepared in small batches every day." },
  { id:"p5", name:"Sunrise Student Mess", type:"College canteen", area:"Hostel Lane", emoji:"🍱", color:"#e8efff", description:"Affordable home-style food for students and local residents." }
];

function dateOffset(offset) {
  const date = new Date();
  date.setHours(12,0,0,0);
  date.setDate(date.getDate() + offset);
  return date.toISOString().slice(0,10);
}
function formatDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return date.toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
}
function todayString() { return dateOffset(0); }

const starterListings = [
  {id:"f1", partnerId:"p1", food:"Veg lunch bowls", category:"Meals", meals:18, collected:0, area:"Shahapur Market", time:"17:30", note:"Rice, dal and seasonal vegetable sabzi.", emoji:"🥗", date:dateOffset(0), status:"available"},
  {id:"f2", partnerId:"p2", food:"Poha snack boxes", category:"Snacks", meals:24, collected:6, area:"College Main Block", time:"16:45", note:"Fresh poha portions from today's canteen service.", emoji:"🍲", date:dateOffset(0), status:"available"},
  {id:"f3", partnerId:"p3", food:"Bread & bun packs", category:"Bakery", meals:15, collected:0, area:"Station Road", time:"19:00", note:"Packed bakery items. Please collect before closing.", emoji:"🥐", date:dateOffset(0), status:"available"},
  {id:"f4", partnerId:"p4", food:"Chapati meal packs", category:"Meals", meals:12, collected:12, area:"Highway Junction", time:"15:30", note:"Today's surplus has been collected by volunteers.", emoji:"🍛", date:dateOffset(0), status:"collected"},
  {id:"f5", partnerId:"p5", food:"Fruit snack cups", category:"Produce", meals:20, collected:0, area:"Hostel Lane", time:"18:15", note:"Seasonal fruit cups prepared this afternoon.", emoji:"🍎", date:dateOffset(0), status:"available"}
];

const starterHistory = [
  {id:"h1", date:dateOffset(0), partnerId:"p1", food:"Veg lunch bowls", reported:18, collected:0, remaining:18, status:"Available"},
  {id:"h2", date:dateOffset(0), partnerId:"p2", food:"Poha snack boxes", reported:24, collected:6, remaining:18, status:"Partially collected"},
  {id:"h3", date:dateOffset(0), partnerId:"p3", food:"Bread & bun packs", reported:15, collected:0, remaining:15, status:"Available"},
  {id:"h4", date:dateOffset(0), partnerId:"p4", food:"Chapati meal packs", reported:12, collected:12, remaining:0, status:"Collected"},
  {id:"h5", date:dateOffset(0), partnerId:"p5", food:"Fruit snack cups", reported:20, collected:0, remaining:20, status:"Available"},
  {id:"h6", date:dateOffset(-1), partnerId:"p1", food:"Rice & dal boxes", reported:30, collected:24, remaining:6, status:"Partially collected"},
  {id:"h7", date:dateOffset(-1), partnerId:"p2", food:"Vegetable sandwiches", reported:16, collected:16, remaining:0, status:"Collected"},
  {id:"h8", date:dateOffset(-1), partnerId:"p3", food:"Evening bread packs", reported:22, collected:15, remaining:7, status:"Partially collected"},
  {id:"h9", date:dateOffset(-2), partnerId:"p4", food:"Paneer rice meals", reported:26, collected:26, remaining:0, status:"Collected"},
  {id:"h10", date:dateOffset(-2), partnerId:"p5", food:"Banana & apple cups", reported:14, collected:10, remaining:4, status:"Partially collected"},
  {id:"h11", date:dateOffset(-3), partnerId:"p1", food:"Mixed veg meal boxes", reported:20, collected:18, remaining:2, status:"Partially collected"},
  {id:"h12", date:dateOffset(-3), partnerId:"p2", food:"Idli snack plates", reported:28, collected:28, remaining:0, status:"Collected"},
  {id:"h13", date:dateOffset(-4), partnerId:"p3", food:"Dinner rolls", reported:17, collected:12, remaining:5, status:"Partially collected"},
  {id:"h14", date:dateOffset(-5), partnerId:"p4", food:"Dal khichdi bowls", reported:21, collected:21, remaining:0, status:"Collected"},
  {id:"h15", date:dateOffset(-6), partnerId:"p5", food:"Veg pulao boxes", reported:25, collected:20, remaining:5, status:"Partially collected"}
];

function readStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : structuredClone(fallback);
  } catch (error) {
    console.warn("Could not read localStorage; using demo data.", error);
    return JSON.parse(JSON.stringify(fallback));
  }
}
let listings = readStorage(STORAGE_KEY, starterListings);
let historyRecords = readStorage(HISTORY_KEY, starterHistory);
function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(listings));
  localStorage.setItem(HISTORY_KEY, JSON.stringify(historyRecords));
}
function partnerFor(id) { return partners.find(p => p.id === id) || partners[0]; }
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
}
function getRemaining(item) { return Math.max(0, Number(item.meals) - Number(item.collected || 0)); }
function listingStatus(item) { return getRemaining(item) <= 0 || item.status === "collected" ? "collected" : "available"; }
function statusClass(status) {
  const lower = String(status).toLowerCase();
  if (lower.includes("collect")) return "collected";
  if (lower.includes("expir")) return "expired";
  return "available";
}
function statusText(item) { return listingStatus(item) === "collected" ? "Collected" : "Available"; }
function getEmoji(food) {
  const value = `${food.category || ""} ${food.food || ""}`.toLowerCase();
  if (value.includes("bread") || value.includes("bun") || value.includes("bakery") || value.includes("pastry")) return "🥐";
  if (value.includes("fruit") || value.includes("apple") || value.includes("banana") || value.includes("produce")) return "🍎";
  if (value.includes("snack") || value.includes("poha") || value.includes("sandwich")) return "🥪";
  if (value.includes("meal") || value.includes("rice") || value.includes("chapati") || value.includes("dal")) return "🍛";
  return "🥗";
}
function syncHistoryForListing(item) {
  let record = historyRecords.find(h => h.id === `h_${item.id}`);
  if (!record) {
    record = {id:`h_${item.id}`, date:item.date || todayString(), partnerId:item.partnerId, food:item.food, reported:Number(item.meals), collected:Number(item.collected || 0), remaining:getRemaining(item), status:"Available"};
    historyRecords.unshift(record);
  }
  record.partnerId = item.partnerId;
  record.food = item.food;
  record.reported = Number(item.meals);
  record.collected = Number(item.collected || 0);
  record.remaining = getRemaining(item);
  record.status = record.remaining === 0 ? "Collected" : record.collected > 0 ? "Partially collected" : "Available";
}
function syncAllHistory() {
  listings.forEach(syncHistoryForListing);
  saveData();
}
function mealsAvailable() { return listings.reduce((sum, item) => sum + (listingStatus(item) === "available" ? getRemaining(item) : 0), 0); }
function mealsRescued() { return historyRecords.reduce((sum, item) => sum + Number(item.collected || 0), 0); }
function renderStats() {
  document.getElementById("statAvailable").innerHTML = `${mealsAvailable()} <small>meals</small>`;
  document.getElementById("statRescued").innerHTML = `${mealsRescued()} <small>meals</small>`;
  document.getElementById("statWeight").innerHTML = `${(mealsRescued() * .4).toFixed(1)} <small>kg</small>`;
  document.getElementById("statPartners").innerHTML = `${partners.length} <small>places</small>`;
  document.getElementById("availableNavCount").textContent = listings.filter(x => listingStatus(x) === "available").length;
  document.getElementById("todayLabel").textContent = new Date().toLocaleDateString("en-IN", {weekday:"short", day:"numeric", month:"short"});
}
function renderFoodRow(item) {
  const partner = partnerFor(item.partnerId);
  return `<div class="food-row">
    <div class="food-emoji">${escapeHTML(item.emoji || getEmoji(item))}</div>
    <div class="food-info"><strong>${escapeHTML(item.food)}</strong><p>${escapeHTML(partner.name)} <span>•</span> ${escapeHTML(item.area || partner.area)}</p></div>
    <div class="food-meta"><div class="meal-number">${getRemaining(item)} <small>meals</small></div><span class="pickup-tag">Pickup by ${escapeHTML(item.time || "—")}</span></div>
  </div>`;
}
function renderOverview() {
  const active = listings.filter(x => listingStatus(x) === "available").slice(0,5);
  document.getElementById("overviewFoodList").innerHTML = active.map(renderFoodRow).join("");
  document.getElementById("overviewEmpty").classList.toggle("hidden", active.length > 0);
  const recent = historyRecords.slice().sort((a,b) => b.date.localeCompare(a.date)).slice(0,5);
  document.getElementById("recentHistoryBody").innerHTML = recent.map(historyRowCompact).join("");
  renderChart();
  document.getElementById("weeklyRescued").textContent = recentWeekCollected();
  document.getElementById("chartTotal").textContent = `${recentWeekCollected()} total`;
}
function historyRowCompact(item) {
  const partner = partnerFor(item.partnerId);
  return `<tr><td>${formatDate(item.date)}</td><td><span class="table-partner">${escapeHTML(partner.name)}</span></td><td><div class="table-food"><span class="tiny-emoji">${getEmoji({food:item.food})}</span><strong>${escapeHTML(item.food)}</strong></div></td><td><span class="table-number">${item.remaining}</span> meals</td><td><span class="status-pill ${statusClass(item.status)}">${escapeHTML(item.status)}</span></td></tr>`;
}
function recentWeekCollected() {
  const start = dateOffset(-6);
  return historyRecords.filter(h => h.date >= start && h.date <= todayString()).reduce((sum,h) => sum + Number(h.collected || 0), 0);
}
function renderChart() {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const date = dateOffset(-i);
    const total = historyRecords.filter(h => h.date === date).reduce((sum,h) => sum + Number(h.collected || 0), 0);
    days.push({date, total, label:new Date(`${date}T12:00:00`).toLocaleDateString("en-IN",{weekday:"short"})});
  }
  const max = Math.max(1, ...days.map(d => d.total));
  document.getElementById("weeklyChart").innerHTML = days.map((d,i) => `<div class="chart-column"><div class="chart-bar-wrap"><div class="chart-bar ${i === days.length-1 ? "today" : ""}" title="${d.total} meals" style="height:${Math.max(4, d.total/max*100)}%"></div></div><span class="chart-day">${d.label}</span></div>`).join("");
}
function renderListings() {
  const search = (document.getElementById("foodSearch")?.value || "").toLowerCase().trim();
  const category = document.getElementById("categoryFilter")?.value || "all";
  const status = document.getElementById("statusFilter")?.value || "available";
  const filtered = listings.filter(item => {
    const partner = partnerFor(item.partnerId);
    const matchesSearch = `${item.food} ${partner.name} ${item.area} ${item.category}`.toLowerCase().includes(search);
    const matchesCategory = category === "all" || item.category === category;
    const matchesStatus = status === "all" || listingStatus(item) === status;
    return matchesSearch && matchesCategory && matchesStatus;
  }).sort((a,b) => b.date.localeCompare(a.date));
  document.getElementById("listingGrid").innerHTML = filtered.map(item => {
    const partner = partnerFor(item.partnerId);
    const remaining = getRemaining(item);
    const collected = listingStatus(item) === "collected";
    return `<article class="listing-card">
      <div class="listing-cover" style="background:linear-gradient(135deg,${partner.color},#fbfcf7)"><span>${escapeHTML(item.emoji || getEmoji(item))}</span><span class="status-pill ${collected ? "collected" : "available"}">${collected ? "Collected" : "Available"}</span></div>
      <div class="listing-body"><span class="listing-category">${escapeHTML(item.category || "Meals")}</span><h3>${escapeHTML(item.food)}</h3><p class="listing-partner">${escapeHTML(partner.name)} · ${escapeHTML(partner.type)}</p>
      <div class="listing-details"><div><span class="detail-label">PICKUP AREA</span><span class="detail-value">⌖ ${escapeHTML(item.area || partner.area)}</span></div><div><span class="detail-label">PICKUP BY</span><span class="detail-value">◷ ${escapeHTML(item.time || "—")}</span></div></div>
      <p class="listing-note">${escapeHTML(item.note || "Help rescue good food from going to waste.")}</p>
      <div class="listing-bottom"><strong>${remaining}<small> meals left</small></strong><button class="collect-btn" data-collect="${escapeHTML(item.id)}" ${collected ? "disabled" : ""}>${collected ? "All collected ✓" : "Mark collected"}</button></div></div>
    </article>`;
  }).join("");
  document.getElementById("listingEmpty").classList.toggle("hidden", filtered.length > 0);
}
function renderHistory() {
  const search = (document.getElementById("historySearch")?.value || "").toLowerCase().trim();
  const filtered = historyRecords.filter(item => {
    const partner = partnerFor(item.partnerId);
    return `${item.food} ${partner.name} ${item.status} ${item.date}`.toLowerCase().includes(search);
  }).sort((a,b) => b.date.localeCompare(a.date));
  document.getElementById("historyTableBody").innerHTML = filtered.map(item => {
    const partner = partnerFor(item.partnerId);
    return `<tr><td>${formatDate(item.date)}</td><td><span class="table-partner">${escapeHTML(partner.name)}</span></td><td><div class="table-food"><span class="tiny-emoji">${getEmoji({food:item.food})}</span><strong>${escapeHTML(item.food)}</strong></div></td><td><span class="table-number">${item.reported}</span> meals</td><td><span class="table-number">${item.collected}</span> meals</td><td><span class="table-number">${item.remaining}</span> meals</td><td><span class="status-pill ${statusClass(item.status)}">${escapeHTML(item.status)}</span></td></tr>`;
  }).join("");
  document.getElementById("historyEmpty").classList.toggle("hidden", filtered.length > 0);
  document.getElementById("historyReported").textContent = historyRecords.reduce((s,h) => s + Number(h.reported || 0), 0);
  document.getElementById("historyCollected").textContent = historyRecords.reduce((s,h) => s + Number(h.collected || 0), 0);
  document.getElementById("historyRemaining").textContent = historyRecords.reduce((s,h) => s + Number(h.remaining || 0), 0);
}
function renderPartners() {
  document.getElementById("partnerCount").textContent = `${partners.length} partners`;
  document.getElementById("partnerGrid").innerHTML = partners.map(partner => {
    const partnerHistory = historyRecords.filter(h => h.partnerId === partner.id);
    const reported = partnerHistory.reduce((s,h) => s + Number(h.reported || 0), 0);
    const rescued = partnerHistory.reduce((s,h) => s + Number(h.collected || 0), 0);
    return `<article class="partner-card"><div class="partner-top"><div class="partner-logo" style="background:${partner.color}">${partner.emoji}</div><div><h3>${escapeHTML(partner.name)}</h3><p>${escapeHTML(partner.type)} · ${escapeHTML(partner.area)}</p></div></div><p class="partner-desc">${escapeHTML(partner.description)}</p><div class="partner-stats"><div><span>Meals reported</span><strong>${reported}</strong></div><div><span>Meals rescued</span><strong>${rescued}</strong></div></div></article>`;
  }).join("");
}
function renderAll() {
  renderStats();
  renderOverview();
  renderListings();
  renderHistory();
  renderPartners();
}
function openModal() {
  const select = document.getElementById("formPartner");
  select.innerHTML = partners.map(p => `<option value="${p.id}">${escapeHTML(p.name)}</option>`).join("");
  document.getElementById("foodModal").classList.remove("hidden");
  document.body.style.overflow = "hidden";
  document.getElementById("formFood").focus();
}
function closeModal() {
  document.getElementById("foodModal").classList.add("hidden");
  document.body.style.overflow = "";
}
let toastTimeout;
function toast(message) {
  const element = document.getElementById("toast");
  element.textContent = message;
  element.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => element.classList.remove("show"), 2600);
}
function navigate(view) {
  document.querySelectorAll(".page-view").forEach(el => el.classList.toggle("active", el.id === `view-${view}`));
  document.querySelectorAll("[data-view]").forEach(el => el.classList.toggle("active", el.dataset.view === view));
  const titles = {overview:"Overview", listings:"Available food", history:"Food history", partners:"Food partners"};
  document.getElementById("breadcrumbCurrent").textContent = titles[view] || "Overview";
  document.getElementById("sidebar").classList.remove("open");
  window.scrollTo({top:0, behavior:"smooth"});
}
function exportCSV() {
  const rows = [["Date","Partner","Food item","Meals reported","Meals collected","Meals remaining","Status"]];
  historyRecords.slice().sort((a,b)=>b.date.localeCompare(a.date)).forEach(item => rows.push([item.date, partnerFor(item.partnerId).name, item.food, item.reported, item.collected, item.remaining, item.status]));
  const csv = rows.map(row => row.map(value => `"${String(value ?? "").replace(/"/g,'""')}"`).join(",")).join("\r\n");
  const blob = new Blob(["\ufeff" + csv], {type:"text/csv;charset=utf-8;"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "foodsave-daily-history.csv"; a.click();
  URL.revokeObjectURL(url);
  toast("Food history exported as CSV.");
}

document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.view)));
document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.go)));
document.getElementById("addFoodBtn").addEventListener("click", openModal);
document.getElementById("addFoodBtn2").addEventListener("click", openModal);
document.getElementById("closeModal").addEventListener("click", closeModal);
document.getElementById("cancelModal").addEventListener("click", closeModal);
document.getElementById("foodModal").addEventListener("click", event => { if (event.target.id === "foodModal") closeModal(); });
document.getElementById("mobileMenu").addEventListener("click", () => document.getElementById("sidebar").classList.toggle("open"));
document.getElementById("foodSearch").addEventListener("input", renderListings);
document.getElementById("categoryFilter").addEventListener("change", renderListings);
document.getElementById("statusFilter").addEventListener("change", renderListings);
document.getElementById("historySearch").addEventListener("input", renderHistory);
document.getElementById("exportHistory").addEventListener("click", exportCSV);
document.getElementById("resetDemo").addEventListener("click", () => {
  if (confirm("Reset FoodSave to its original fictional demo data? Your locally added listings and history will be replaced.")) {
    listings = JSON.parse(JSON.stringify(starterListings));
    historyRecords = JSON.parse(JSON.stringify(starterHistory));
    saveData(); renderAll(); toast("Demo data has been reset.");
  }
});
document.getElementById("foodForm").addEventListener("submit", event => {
  event.preventDefault();
  const partnerId = document.getElementById("formPartner").value;
  const food = document.getElementById("formFood").value.trim();
  const meals = Number(document.getElementById("formMeals").value);
  const area = document.getElementById("formArea").value.trim();
  if (!food || !area || !Number.isFinite(meals) || meals < 1) { toast("Please complete the required fields."); return; }
  const item = {
    id:`f${Date.now()}`, partnerId, food, category:document.getElementById("formCategory").value,
    meals, collected:0, area, time:document.getElementById("formTime").value,
    note:document.getElementById("formNote").value.trim(), emoji:getEmoji({food, category:document.getElementById("formCategory").value}),
    date:todayString(), status:"available"
  };
  listings.unshift(item);
  syncHistoryForListing(item);
  saveData(); renderAll(); closeModal(); event.target.reset();
  document.getElementById("formMeals").value = 20;
  document.getElementById("formTime").value = "18:00";
  navigate("listings");
  toast("Food listing published successfully.");
});
document.getElementById("listingGrid").addEventListener("click", event => {
  const button = event.target.closest("[data-collect]");
  if (!button) return;
  const item = listings.find(x => x.id === button.dataset.collect);
  if (!item || listingStatus(item) === "collected") return;
  const remaining = getRemaining(item);
  const quantity = prompt(`How many of the ${remaining} remaining meals were collected?`, String(remaining));
  if (quantity === null) return;
  const count = Number(quantity);
  if (!Number.isInteger(count) || count < 1 || count > remaining) { toast(`Enter a whole number from 1 to ${remaining}.`); return; }
  item.collected = Number(item.collected || 0) + count;
  if (getRemaining(item) === 0) item.status = "collected";
  syncHistoryForListing(item);
  saveData(); renderAll();
  toast(`${count} meal${count === 1 ? "" : "s"} marked as collected.`);
});
document.addEventListener("keydown", event => { if (event.key === "Escape") closeModal(); });

if (!localStorage.getItem(STORAGE_KEY) || !localStorage.getItem(HISTORY_KEY)) saveData();
renderAll();
