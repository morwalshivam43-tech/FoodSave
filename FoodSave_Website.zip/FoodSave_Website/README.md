# FoodSave — Responsive Food Rescue Website

A responsive front-end demo built with **HTML, CSS, and vanilla JavaScript**. Data is saved in the browser with `localStorage`.

## Run the website
1. Extract `FoodSave_Website.zip`.
2. Open `index.html` in a modern browser.
3. No npm install, build step, server, or API key is needed.

## Features
- Responsive dashboard for desktop, tablet, and mobile
- 5 fictional restaurants and canteens
- Sample surplus-food listings
- Add a new food listing
- Search listings and filter by category/status
- Mark all or some meals as collected
- Daily remaining-food history with 15 sample records across the last 7 days
- Weekly rescued-meals chart and summary cards
- Food-partner cards with reported/rescued totals
- Export history to CSV
- Persistent data through `localStorage`
- Reset demo data button

## Files
- `index.html` — page structure
- `style.css` — responsive layout and styling
- `script.js` — sample data, localStorage, filters, listing form, history, and CSV export

## Important notes
- All restaurant/canteen names and records are fictional demo data.
- `localStorage` is specific to the browser and device. Clearing browser site data can remove saved changes.
- This is a front-end college project prototype, not a production food-safety or donation coordination system. Do not publish personal contact details or treat demo listings as real food availability.
